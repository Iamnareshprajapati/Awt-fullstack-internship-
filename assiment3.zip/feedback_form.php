
<!DOCTYPE html>
<html lang="en">
<head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>feedback</title>
<style> .row ,.form-group,.my-3,.text-center{
  text-align: center;
  

}
.feed-back{
  text-align: center;
  font-size: larger;
}

body{
    background-color: rgb(34, 167, 225);
    font-size: larger;
} .gender{
   text-align: center;
   font-size: larger;
}
 button {
  
  background-color: greenyellow;
  border: 100px;
  font-size: larger;
 } 
 

 
 
.checked {
  color: orange; 
}.star-rating{
  text-align: center;

}


</style> 
</head>
<body> 


       <h1>feedback our classroom</h1>
       <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
        <form action="feedback.php" method="post" class="php-email-form" >
          <div class="row">
            <div class="form-group col-md-6">
              <label for="name">Your Name</label>
              <input type="text" name="name" class="form-control" id="yourname" required  style="margin: 25px ;">
            </div>
            <div class="form-group col-md-6">
              <label for="name">Your Email</label>
              <input type="email" class="form-control" name="email" id="email" required style="margin: 25px;">
            </div> 
            <div class="gender">
            <input type="radio"  name="gender" value="male">male <br>
            <input type="radio"  name="gender" value="female">female <br>
            <div class="city">
            city  <select city="city" name="city">
              <option value="ahemadabad">ahemdabad</option>
              <option value="banashkantha">banashkantha</option>
              <option value="mahesana">mahesana</option>
              <option value="anand">anand</option>
              <option value="surat">surat</option></select>
          </div>
          </div>
          <div class="form-group">
            <label for="name">division</label>
            <input type="text" class="form-control" name="subject" id="subject" required style="margin: 40px;">
          </div>
          <div class="feed-back">
         Feedback:<Br>
          <textarea rows="6" cols="50" name="feedback " ></textarea><br></div>
          <!-- <div class="my-3">
            <div class="loading">Loading</div>
            <div class="error-message"></div>
            <div class="sent-message">Your message has been sent. Thank you!</div>
          </div> -->
          <div class="star-rating">
      <h2>Star Rating</h2>

      <span class="fa fa-star checked"></span>
      <span class="fa fa-star checked"></span>
      <span class="fa fa-star checked"></span>
      <span class="fa fa-star"></span>
      <span class="fa fa-star" ></span></div>
      <div class="text-center"><input type="submit" value="Submit">
        <button type="reset">reset</button></div>
    </form>
  </div>
      
    
</body>
</html>